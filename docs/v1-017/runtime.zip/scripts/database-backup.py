#!/usr/bin/env python3
"""Read-only FaraiOS logical export; only encrypted output is retained. Never restores."""
import os,sys,json,subprocess,tempfile,pathlib,datetime,hashlib,tarfile,uuid,re,select
from database_recovery import fingerprints,schema_grants
PROJECT='rxelmugnucfajrqmphhe'
SCHEMAS=['public','auth','extensions','booking_private','customer_private','enquiry_private','invoice_private','quote_private','request_private','staff_private','waitlist_private']
ROOT=pathlib.Path(__file__).resolve().parents[1]
class BackupError(Exception):pass
def run(args,env,stdin=None):
 try:p=subprocess.run(args,env=env,input=stdin,capture_output=True,timeout=900)
 except (OSError,subprocess.TimeoutExpired):raise BackupError('Backup command unavailable or timed out') from None
 if p.returncode:
  detail=p.stderr.decode(errors='replace').lower();reason='command failure'
  for pattern,label in [('password authentication failed','database password rejected'),('certificate verify failed','TLS certificate verification failed'),('server version:','PostgreSQL client/server version mismatch'),('permission denied','database or filesystem permission denied'),('manifest unknown','PostgreSQL container image unavailable'),('could not translate host name','DNS resolution failed'),('connection timed out','database connection timed out'),('connection refused','database connection refused'),('read-only transaction','dump operation conflicts with read-only session')]:
   if pattern in detail:reason=label;break
  stage=next((x for x in ['pg_dumpall','pg_dump','pg_restore','psql','gpg'] if x in args or any(a.endswith('/'+x) for a in args)),'client')
  raise BackupError('Backup '+stage+' failed: '+reason+'; no usable backup was published')
 return p.stdout

def backup():
 test=os.environ.get('FARAIOS_BACKUP_TEST')=='1';host=os.environ.get('PGHOST','');user=os.environ.get('PGUSER','')
 if test and host not in ('127.0.0.1','localhost'):raise BackupError('Test mode is restricted to loopback')
 if not test and not ((host=='db.'+PROJECT+'.supabase.co' and user=='postgres') or (re.fullmatch(r'[a-z0-9.-]+\.pooler\.supabase\.com',host) and user=='postgres.'+PROJECT)):
  raise BackupError('Configure the exact FaraiOS direct or session-pooler connection')
 if not test and (os.environ.get('PGPORT','5432')!='5432' or os.environ.get('PGDATABASE')!='postgres' or not os.environ.get('PGPASSWORD')):raise BackupError('Use session port 5432, postgres database and private password')
 key=os.environ.get('BACKUP_PASSPHRASE','')
 if len(key)<32 or '\n' in key or '\r' in key:raise BackupError('Set a strong backup passphrase of at least 32 characters; retain an offline copy')
 output=pathlib.Path(os.environ.get('BACKUP_OUTPUT','')).resolve()
 if output==ROOT or ROOT in output.parents or not os.environ.get('BACKUP_OUTPUT'):raise BackupError('Encrypted backups must be outside the repository/web root')
 output.mkdir(parents=True,exist_ok=True);output.chmod(0o700)
 pg=os.environ.get('PG_BIN','');image=os.environ.get('BACKUP_PG_IMAGE','')
 if not pg and not image:raise BackupError('Configure PostgreSQL client directory or approved container')
 if image and image!='postgres:17.11':raise BackupError('Unapproved PostgreSQL image')
 env=dict(os.environ);env.pop('BACKUP_PASSPHRASE',None);env['PGOPTIONS']='-c default_transaction_read_only=on -c statement_timeout=600000 -c lock_timeout=5000'
 if not test:env['PGSSLMODE']='verify-full';env['PGSSLROOTCERT']='/etc/ssl/certs/ca-certificates.crt'
 gpg_env=dict(os.environ);gpg_env.pop('PGPASSWORD',None);gpg_env.pop('BACKUP_PASSPHRASE',None)
 os.umask(0o077)
 with tempfile.TemporaryDirectory(prefix='faraios-backup-') as td:
  tmp=pathlib.Path(td);tmp.chmod(0o700);
  if not test:
   ca=ROOT/'config/certificates/supabase-prod-ca-2021.crt'
   (tmp/'root.crt').write_bytes(pathlib.Path('/etc/ssl/certs/ca-certificates.crt').read_bytes()+b'\n'+ca.read_bytes())
   env['PGSSLROOTCERT']=str(tmp/'root.crt')
  (tmp/'gnupg').mkdir(mode=0o700);gpg_env['GNUPGHOME']=str(tmp/'gnupg')
  def cmd(binary,args):
   if image:
    return ['docker','run','--rm','-i','--network=host','--read-only','--user',str(os.getuid())+':'+str(os.getgid()),'--mount','type=bind,src='+td+',dst='+td,'--mount','type=bind,src=/etc/ssl/certs/ca-certificates.crt,dst=/etc/ssl/certs/ca-certificates.crt,readonly',*sum((['--env',k] for k in ['PGHOST','PGPORT','PGUSER','PGPASSWORD','PGDATABASE','PGSSLMODE','PGSSLROOTCERT','PGOPTIONS']),[]),image,binary,*args]
   return [str(pathlib.Path(pg)/binary),*args]
  # Hold one read-only MVCC snapshot for metadata and pg_dump; source never mutates.
  keeper=subprocess.Popen(cmd('psql',['-XAtq','-v','ON_ERROR_STOP=1']),env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  try:
   keeper.stdin.write(b'begin isolation level repeatable read read only;select pg_export_snapshot();\n');keeper.stdin.flush()
   if not select.select([keeper.stdout],[],[],60)[0]:raise BackupError('Snapshot connection timed out')
   snapshot=keeper.stdout.readline().decode().strip()
   if not re.fullmatch(r'[0-9A-Fa-f-]+',snapshot):raise BackupError('Read-only snapshot unavailable')
   query="select coalesce(json_agg(nspname order by nspname),'[]'::json) from pg_namespace where nspname in ('supabase_migrations','storage')"
   def sql(query):
    return run(cmd('psql',['-XAtq','-v','ON_ERROR_STOP=1','-c',"begin isolation level repeatable read read only;set transaction snapshot '"+snapshot+"';"+query+';commit']),env).decode().strip()
   optional=json.loads(sql(query))
   schemas=SCHEMAS+optional
   recorded=fingerprints(sql,schemas);grants=schema_grants(sql,schemas)
   args=['--snapshot='+snapshot,'--format=custom','--no-owner','--strict-names','--lock-wait-timeout=5000','--file='+str(tmp/'database.dump')]
   for schema in schemas:args+=['--schema='+schema]
   run(cmd('pg_dump',args),env)
   # Catalog metadata only; custom-role password hashes are explicitly excluded.
   (tmp/'roles.sql').write_bytes(run(cmd('pg_dumpall',['--roles-only','--no-role-passwords']),env))
   listing=run(cmd('pg_restore',['--list',str(tmp/'database.dump')]),env)
   if not listing or not (tmp/'database.dump').stat().st_size:raise BackupError('Empty archive rejected')
   manifest=dict(format='faraios-logical-backup-v2',table_fingerprints=recorded,schema_grants=grants,project=PROJECT,created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),schemas=schemas,source_commit=os.environ.get('GITHUB_SHA','local'),database_sha256=hashlib.sha256((tmp/'database.dump').read_bytes()).hexdigest(),roles_sha256=hashlib.sha256((tmp/'roles.sql').read_bytes()).hexdigest(),limitations=['Storage object bytes and external runtime secrets are not included','Vault/Realtime/provider internals excluded; provider-supported Auth/role restore needs isolated verification','No custom-role passwords; secrets must be recovered separately'])
  finally:
   if keeper.poll() is None:
    keeper.terminate()
    try:keeper.wait(timeout=10)
    except subprocess.TimeoutExpired:keeper.kill();keeper.wait()
   for stream in (keeper.stdin,keeper.stdout,keeper.stderr):stream.close()
  (tmp/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
  bundle=tmp/'backup.tar'
  with tarfile.open(bundle,'w') as tar:
   for name in ['database.dump','roles.sql','manifest.json']:tar.add(tmp/name,arcname=name)
  encrypted=tmp/'backup.tar.gpg'
  base=['gpg','--batch','--yes','--no-symkey-cache','--pinentry-mode','loopback','--passphrase-fd','0']
  run(base+['--symmetric','--cipher-algo','AES256','--s2k-digest-algo','SHA512','--s2k-mode','3','--s2k-count','65011712','--output',str(encrypted),str(bundle)],gpg_env,(key+'\n').encode())
  # Decrypt independently and verify plaintext archive checksum before publishing ciphertext.
  verified=tmp/'verified.tar';run(base+['--output',str(verified),'--decrypt',str(encrypted)],gpg_env,(key+'\n').encode())
  if hashlib.sha256(verified.read_bytes()).digest()!=hashlib.sha256(bundle.read_bytes()).digest():raise BackupError('Encryption verification failed')
  name='faraios-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex[:8]+'.tar.gpg'
  target=output/name;os.replace(encrypted,target);target.chmod(0o600)
  (output/(name+'.sha256')).write_text(hashlib.sha256(target.read_bytes()).hexdigest()+'  '+name+'\n')
  print(json.dumps({'status':'encrypted_backup_verified','project':PROJECT,'file':name,'bytes':target.stat().st_size,'scope':'application/Auth schema-data, optional migration and Storage metadata; roles without passwords','restore_test_required':True}))
  return target
if __name__=='__main__':
 try:backup()
 except BackupError as error:print(str(error),file=sys.stderr);sys.exit(1)
 except (ValueError,OSError):print('Backup failed: invalid configuration or private filesystem unavailable; no plaintext is published.',file=sys.stderr);sys.exit(1)
